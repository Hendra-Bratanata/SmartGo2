package go.id.smartgo

data class MAPSResponse(val Data:List<MAPS>)