package go.id.smartgo

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    lateinit var apiReposirtory: ApiReposirtory

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnON.setOnClickListener {
            apiReposirtory.doRequest(PromoApi.setData(btnON.text.toString()))
        }
        btnOFF.setOnClickListener {
            apiReposirtory.doRequest(PromoApi.setData(btnOFF.text.toString()))
        }
    }
}
