package go.id.smartgo

object PromoApi {
    fun setData(r1:String):String{
        val url = BuildConfig.BASE_URL+"setData.php?r1=$r1"
        return url
    }
}