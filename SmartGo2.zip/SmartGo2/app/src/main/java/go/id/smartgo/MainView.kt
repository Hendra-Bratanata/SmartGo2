package go.id.smartgo

interface MainView {
    fun showDataMap(listMap: List<MAPS>)
}